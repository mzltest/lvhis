/api/room_info?key= x
/api/room_cron?key= x
/api/liveinfo?key=  
/api/captinfo?key=
/api/getimg?key=


table:roominfo
{
  'key':roomid,
  'sessions':{
    '2023-01-03 13:52:46':'liveinfokey'
  },
  'lastts':121122
}


table:liveinfo
{
  'key':liveinfokey,
  'captures':{'ts':key}
}

table:captinfo
{
  'key':'captkey',
  'ts':10202010,
  'chatdata':{},
  'livedata':{},
  'keyframekey':''
}

table:keyframes
{'key':'key',
'data':'data in base64,128kb max'}


{
"area": 6,
"attentions": 21642,
"cate_name": "虚拟主播",
"cover": "//i0.hdslb.com/bfs/live-key-frame/keyframe01031556000000024125xyvq0c.jpg",
"hit_columns": [],
"is_live_room_inline": 0,
"live_status": 1,
"live_time": "2023-01-03 13:52:46",
"online": 106923,
"rank_index": 1,
"rank_offset": 1,
"rank_score": 1000000000,
"roomid": 24125,
"short_id": 0,
"tags": "虚拟主播,杂谈,唱歌",
"title": "【歌杂】2023年的第3天咯！！",
"type": "live_room",
"uface": "//i2.hdslb.com/bfs/face/4045bf8a0b2b9a5fcf144d654cd169666b8d68bc.jpg",
"uid": 1583472,
"uname": "鲸落落raku",
"user_cover": "//i0.hdslb.com/bfs/live/new_room_cover/6ad3be6cdc4efc5834a0a04cc5eaf6837a58c31d.jpg",
"watched_show": {
  "switch": true,
  "num": 1131,
  "text_small": "1131",
  "text_large": "1131人看过",
  "icon": "https://i0.hdslb.com/bfs/live/a725a9e61242ef44d764ac911691a7ce07f36c1d.png",
  "icon_location": "",
  "icon_web": "https://i0.hdslb.com/bfs/live/8d9d0f33ef8bf6f308742752d13dd0df731df19c.png"
}
}